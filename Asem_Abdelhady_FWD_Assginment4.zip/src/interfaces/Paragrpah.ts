export interface IParagrpah {
  header: string;
  body: string;
}
