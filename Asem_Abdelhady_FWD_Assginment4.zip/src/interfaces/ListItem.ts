export interface IListItem {
  title: string;
  content: string;
}
