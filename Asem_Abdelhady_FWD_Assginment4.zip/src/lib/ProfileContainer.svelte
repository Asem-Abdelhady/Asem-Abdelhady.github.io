<script>
  import LeftCard from "./LeftCard.svelte";
  import RightCard from "./RightCard.svelte";
</script>

<div id="profile_container">
  <LeftCard />
  <RightCard />
</div>

<style>
  #profile_container {
    display: flex;
  }
</style>
