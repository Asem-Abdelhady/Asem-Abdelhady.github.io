export interface IId {
  id: number;
}
